<<PBRT`
<<Graphics`Polyhedra`
coolShape=Truncate[Polyhedron[Dodecahedron],.4]
Show[coolShape]
PBRTExport["~/cool.pbrt",coolShape]
